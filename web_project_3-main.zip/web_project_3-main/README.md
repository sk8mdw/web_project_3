# Project 3: From Homeland to Homeland
## Overview  
This project takes it's design details from Figma, showcases several locations around the world.  The locations are home bases or homelands for myself and several of the Practicum team members.  
  
### Technologies Used
This project is written in HTML amd CSS.  The CSS includes flexbox, grid, and grid template areas layouts.
